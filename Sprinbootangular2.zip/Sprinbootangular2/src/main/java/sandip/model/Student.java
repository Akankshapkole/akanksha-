package sandip.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Entity
@Table
public class Student {
	@Id
	@GeneratedValue
	@Column
	private Integer id;
	
	
	@Column
	private String date1;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDate1() {
		return date1;
	}
	public void setDate1(String date1) {
		this.date1 = date1;
	}
	public Integer getAmountdeducted() {
		return amountdeducted;
	}
	public void setAmountdeducted(Integer amountdeducted) {
		this.amountdeducted = amountdeducted;
	}
	public Integer getAmountrefunded() {
		return amountrefunded;
	}
	public void setAmountrefunded(Integer amountrefunded) {
		this.amountrefunded = amountrefunded;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	@Column
	private Integer amountdeducted;
	@Column
	private Integer amountrefunded;
	@Column
	private String reason;
}
