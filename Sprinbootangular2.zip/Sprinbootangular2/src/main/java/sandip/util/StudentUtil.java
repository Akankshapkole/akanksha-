package sandip.util;

import org.springframework.stereotype.Component;

import sandip.model.Student;

@Component
public class StudentUtil {

	public void mapToActualObject(Student actual, Student student) {
		if(student.getDate1()!=null)
			actual.setDate1(student.getDate1());
		if(student.getAmountdeducted()!=null)
		actual.setAmountdeducted(student.getAmountdeducted());
		
		if(student.getAmountrefunded()!=null)
			actual.setAmountrefunded(student.getAmountrefunded());
		if(student.getReason()!=null)
		actual.setReason(student.getReason());
	}

}
